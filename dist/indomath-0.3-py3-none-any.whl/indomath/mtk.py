from math import *
 
def terbesar(*args):
    max(args)
def terkecil(*args):
    min(args)
def nilai_cos(derajat):
    cos(derajat)
def nilai_sin(derajat):
    sin(derajat)
def nilai_tan(derajat):
    tan(derajat)