from setuptools import setup
setup(name='indomath',
      version='0.3',
      description='Sebuah progam matematika',
      author='VincentVe,Febrianto',
      author_email='sayuzvernando1@gmail.com',
      license='MIT',
      packages=['indomath']
)