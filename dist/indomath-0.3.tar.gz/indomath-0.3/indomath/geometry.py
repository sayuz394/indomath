
phi = 22/7

def luas_segitiga(a,t):
    result = 1/2 * a * t
    print(result)
def keliling_segitiga(a,b,c):
    print(a+b+c)
def luas_persegi_panjang(p,l):
    result = p * l 
    print(result)
def keliling_persegi_panjang(p,l):
    print(2 * (p+l))
def luas_persegi(a):
    print(a * a)
def keliling_persegi(s):
    print(4 * s)
def luas_jajar_genjang(a,t):
    print(a * t)
def keliling_jajar_genjang(a,b,c,d):
    print(a + b + c + d)
def luas_lingkaran(r):
    print(phi * r * r)
def keliling_lingkaran(r,d):
    print(2*phi*r)
def keliling_trapesium(a,b,c,d):
    print(a + b + c + d)
def luas_trapesium(a,b,t):
    print(1/2 * (a+b) * t)
def luas_layang(x,y):
    print(1/2*x*y)
def keliling_layang(a,b,c,d):
    print(a + b + c + d)
def luas_belah_ketupat(x,y):
    print(1/2 * x * y)
def keliling_belah_ketupat(a,b,c,d):
    print(a + b + c + d)

